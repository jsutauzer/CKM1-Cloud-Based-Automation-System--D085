# # encoding: utf-8

describe package('cri-o') do
  it { should be_installed }
end
